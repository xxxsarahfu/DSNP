/****************************************************************************
  FileName     [ cirMgr.h ]
  PackageName  [ cir ]
  Synopsis     [ Define circuit manager ]
  Author       [ Chung-Yang (Ric) Huang ]
  Copyright    [ Copyleft(c) 2008-present LaDs(III), GIEE, NTU, Taiwan ]
****************************************************************************/

#ifndef CIR_MGR_H
#define CIR_MGR_H

#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <array>//

using namespace std;

#include "cirDef.h"

extern CirMgr *cirMgr;

// TODO: Define your own data members and member functions
class CirMgr
{
public:
   //friend class CirGate; 
   //CirMgr(){}

   CirMgr() : M(0), I(0), L(0), O(0), A(0), glist(0){}
   ~CirMgr() {
    //if(glist.size() != 0){
    for(int i = 0; i < glist.size(); i++)
      delete glist[i];
    glist.clear();
    //delete[] glist;
    //delete glist;
    //}
  }

   // Access functions
   // return '0' if "gid" corresponds to an undefined gate.
   CirGate* getGate(unsigned gid) const;

   // Member functions about circuit construction
   bool readCircuit(const string&);

   // Member functions about circuit reporting
   void printSummary() const;
   void printNetlist();// const;
   void printPIs() const;
   void printPOs() const;
   void printFloatGates() const;
   void writeAag(ostream&) ;//const;

   //myself
   bool readHeader(string&);
   void connectCircuit(CirGate*,CirGate*,int);
   void buildCircuit(GateList&);

   void DFSTraversal(CirGate*);
   void DFSlistbuild();
   void DFSReset();



private://myself

  unsigned int gid;
  //number of...
  unsigned int M;
  unsigned int I;
  unsigned int L;
  unsigned int O;
  unsigned int A;

  //literals
  vector<unsigned int> PI;
  vector<unsigned int> LA;
  vector<unsigned int> PO;
  //vector<std::array<unsigned int,3> > AD;
  vector<unsigned int> li;
  vector<unsigned int> ID;
  vector<unsigned int> trueAIG;

  //glist
  //vector<CirGate*> glist; 
  GateList glist;
  //CirGate* fanin, fanout;
  GateList DFSlist;

//(ANDGate)glist[1][2] -> fu();



};

#endif // CIR_MGR_H
