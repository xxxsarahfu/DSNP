 /****************************************************************************
  FileName     [ cirGate.h ]
  PackageName  [ cir ]
  Synopsis     [ Define basic gate data structures ]
  Author       [ Chung-Yang (Ric) Huang ]
  Copyright    [ Copyleft(c) 2008-present LaDs(III), GIEE, NTU, Taiwan ]
****************************************************************************/

#ifndef CIR_GATE_H
#define CIR_GATE_H

#include <string>
#include <vector>
#include <iostream>
#include "cirDef.h"

using namespace std;

class CirGate;

//------------------------------------------------------------------------
//   Define classes
//------------------------------------------------------------------------
// TODO: Define your own data members and member functions, or classes
class CirGateV
{
public:
    #define NEG 0x1
    CirGateV(const CirGate* gate,size_t phase):
        _gateV((size_t)gate + phase){}//phase = 0 or 1
    CirGate* gate() const {return (CirGate*)(_gateV & ~size_t(NEG));}
    bool isInv() const {return (_gateV & NEG);}
  
private:
    size_t _gateV;
};


class CirGate
{
  friend class cirMgr;//

public:
  CirGate(unsigned gid, unsigned lineNo = 0): gateid(gid), lineNum(lineNo), name(""),_ref(_globalRef) {
    invert_or_not.push_back(true);
    invert_or_not.push_back(true);
    float_or_not = false;
    def_or_not = false;
  }
  virtual ~CirGate() {fanin.clear(); fanout.clear();}

  // Basic access methods
  string getTypeStr() const { return type; }
  unsigned getLineNo() const { return lineNum; }
  unsigned getID() const { return gateid; }
  string getSymbol() const { return name; }
  void setSymbol(string sym){ name = sym; }


  // Printing functions
  //virtual 
  void printGate() const {}//?
  void reportGate() const;
  void reportFanin(int level); //const;
  void reportFanout(int level);// const;
  void myFanin(CirGate*, int, unsigned, bool);
  void myFanout(CirGate*, int, unsigned, bool);


  //DFTraversal
  bool isGlobalRef(){ return (_ref == _globalRef); } 
  void setToGlobalRef(){ _ref = _globalRef; } 
  static void setGlobalRef() { _globalRef++; }
  
  //unsigned int colNo;
  unsigned gateid;
  unsigned lineNum; 
  vector<CirGate*> fanin;
  vector<CirGate*> fanout;
  vector<bool> invert_or_not;

  bool float_or_not;
  bool def_or_not;
  unsigned in[2],op;

  //DFTraversal
  



private:


protected:
  //unsigned lineNum;//?????
  //unsigned int colNo;
  //unsigned gateid;
  //unsigned in1, in2, op;
  //vector<CirGate*> fin, fout;
  //unsigned gateliteral;//?
  string type, name;
  static unsigned _globalRef;
  unsigned _ref;

};

class PIGate: public CirGate
{
public:
  PIGate(unsigned gid = 0, unsigned lineNo = 0)
    :CirGate(gid, lineNo) { type = "PI"; gateid = gid; lineNum = lineNo;
    }//gateid , lineno 
  ~PIGate(){};

};

class POGate: public CirGate
{
public:
  POGate(unsigned gid = 0, unsigned lineNo = 0)
    :CirGate(gid, lineNo) { type = "PO"; gateid = gid; lineNum = lineNo;}//id, line
  ~POGate(){};

};

class ANDGate: public CirGate
{
public:
  ANDGate(unsigned gid = 0, unsigned lineNo = 0)//, unsigned i1 = 0, unsigned i2 = 0)
    :CirGate(gid, lineNo){ type = "AIG"; gateid = gid; lineNum = lineNo;} //in1 = pi1; in2 = pi2;}
  ~ANDGate(){};

};

class UNDEFGate: public CirGate
{
public:
  UNDEFGate(unsigned gid = 0, unsigned lineNo = 0)//id only cuz noline???
    :CirGate(gid, lineNo){type = "UNDEF"; gateid = gid; lineNum = lineNo;}
  ~UNDEFGate(){};

};

class NOGate: public CirGate
{
public:
  NOGate(unsigned gid = 0, unsigned lineNo = 0)//id only cuz noline???
    :CirGate(gid, lineNo){type = "NO"; gateid = gid; lineNum = 0;}
  ~NOGate(){};

};


class CONSTGate: public CirGate
{
public:
  CONSTGate(unsigned gid = 0, unsigned lineNo = 0)
    :CirGate(gid, lineNo) { type = "CONST"; gateid = 0; lineNum = 0;}
  
  ~CONSTGate(){};

};

class LAGate: public CirGate
{//care
};






#endif // CIR_GATE_H
