#include "p2Table.h"

using namespace std;

// Implement member functions of class Row and Table here

bool
Table::read(const string& csvFile)
{
  return true; // TODO
}
